import express from 'express';
import api from './routes/api';
import serverRender from './routes/serverRender';
import path from 'path';
var webpack = require('webpack')
var webpackDevMiddleware = require('webpack-dev-middleware')
var webpackHotMiddleware = require('webpack-hot-middleware')
var webpackConfig = require('../webpack.dev.config')

const app = express();

app.set('view engine', 'ejs');

app.use(express.static(path.join(__dirname, '../dist')));

app.set('views', path.join(__dirname, '../src'));

app.use('/api', api);

app.use('*', serverRender);


var compiler = webpack(webpackConfig)

console.log(webpackConfig.output.publicPath,'---- webpackConfig.output------')
app.use(require("webpack-dev-middleware")(compiler, {
	noInfo: true, publicPath: webpackConfig.output.publicPath
}));


//app.use(webpackDevMiddleware(compiler, { noInfo: true, publicPath: config.output.publicPath }))
app.use(webpackHotMiddleware(compiler))

const port = 8888;

app.listen(port, () => console.log(`server started，at ${port}`));

