import React from 'react';
import { connect } from 'react-redux';

export default connect(()=>({}), {})(() => (
    <div>404</div>
));