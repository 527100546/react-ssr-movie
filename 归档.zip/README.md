### Description

It is a simple demo with Redux, React-router and React server side rendering.

### Usage
```
npm install
npm start
```
Open http://localhost:8888. 

