import React from 'react';
export default () => <p>数据加载中。。。</p>;
